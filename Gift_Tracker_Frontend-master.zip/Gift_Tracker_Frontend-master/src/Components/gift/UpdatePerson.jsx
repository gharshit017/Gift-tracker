import React from "react";

export default function UpdatePerson() {
  return <div>UpdatePerson</div>;
}
